import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Test;
import org.project.dao.LogInDAO;

import com.mysql.jdbc.Connection;

import org.dabase.connection.DatabaseConnection;

public class JUnitTest {

	
	@Test
	public void testGetConnection() {
	Connection db = DatabaseConnection.getConnection();
	//assertFalse(db.,false);

	}
	
	@Test
    public void getConnectionTest() {
		DatabaseConnection connection = new DatabaseConnection();
        Connection connection1 = DatabaseConnection.getConnection();
        assertEquals(connection1 != null, true);
    }
	}
	
	

